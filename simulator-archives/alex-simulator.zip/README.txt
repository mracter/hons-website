To run, you need Java 8, then simply java -jar alex-simulator.jar

Arguments:
--simulation-config=configs/mediumSimConfig.yml # choose the size of the task; see the configs folder
--morphology-config=morphs/3ult.yml # choose the morphology; see the morphs folder

--population=700 (or -p 700) # choose the population size
--tournament-size=7 (or -t 7) # choose the tournament size for the GP tournament selector
--generation-limit=70 (or -g 70) # choose the number of generations to run before terminating

--run-index=0 (or -r 0) # the code appends the run index to the output filenames as -r#, e.g. 3ult-p700-t7-medium-r0.csv)
--output-dir=results (or -o results) # choose the output directory
