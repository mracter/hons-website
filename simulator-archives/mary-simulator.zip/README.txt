README FOR MARY'S SIMULATORS
============================

==================
HOMOGENEOUS TEAMS:
==================
	SYNOPSIS:
		java -jar hons-simulator-homogeneous.jar --experiment-config <experiment-config-path> --simulation-config <simulation-config-path> ( [-c <complement-string> [-cn <repeat-complement> ] | [-v --controller <controller-file-path> --morphology <morphology-file-path>])

	EXAMPLE:

		TESTING:
			java -jar hons-simulator-homogeneous.jar --experiment-config configs/experimentConfig_hom_large.yml --simulation-config configs/largeSimConfig.yml -c 1.0_1.0_1.0 -cn 10

		VISUALISATION:
			java -jar hons-simulator-homogeneous.jar --experiment-config configs/experimentConfig.yml --simulation-config configs/simulationConfig.yml -v --controller results/106net.tmp --morphology results/106morph.tmp
			
	HELP:
		java -jar hons-simulator-homogeneous.jar --help

====================
HETEROGENEOUS TEAMS:
====================
	SYNOPSIS:
		java -jar hons-simulator-homogeneous.jar --experiment-config <experiment-config-path> --simulation-config <simulation-config-path> ( [-c <complement-string> [-cn <repeat-complement> ] | [-v -h -team <path-to-teams>])

	EXAMPLE:
	
		TESTING:
			java -jar hons-simulator-heterogeneous.jar --experiment-config configs/experimentConfig_het_large.yml --simulation-config configs/largeSimConfig.yml -c 1.0_1.0_1.0 -cn 10
		
		VISUALISATION:
		java -jar hons-simulator-heterogeneous.jar --experiment-config configs/experimentConfig_het_large.yml --simulation-config configs/largeSimConfig.yml -v -h -team results/137.158.60.220/team/
		
	HELP:
		java -jar hons-simulator-heterogeneous.jar --help

